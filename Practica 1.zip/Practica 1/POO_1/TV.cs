﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POO_1
{
    class TV
    {
        public string color = "", resolucion = "", marca = "", pantalla = "", modelo = "", forma = "";

        public void Enciende()
        {
            Console.WriteLine("La TV esta encendida");
        }

        public void Apaga()
        {
            Console.WriteLine("Apagando equipo");
        }

        public void Transmite()
        {
            Console.WriteLine("Transmitiendo señal de cable");
        }

        public void Reproduce()
        {
            Console.WriteLine("Reprodciendo Musica");
        }

        public void Comunica()
        {
            Console.WriteLine("Comunicando con dispositivo movil");
        }
    }
}
